﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebApplication1.Models
{
    public partial class cancionContext : DbContext
    {
        public cancionContext()
        {
        }

        public cancionContext(DbContextOptions<cancionContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Album> Albums { get; set; } = null!;
        public virtual DbSet<Cancion> Canciones { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.\\SQLExpress;Database=songs;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Album>(entity =>
            {
                entity.ToTable("Album");

                entity.Property(e => e.ID).HasColumnName("id");

                entity.Property(e => e.Artista).HasMaxLength(50).IsUnicode(false).HasColumnName("artista");

                entity.Property(e => e.Copyright).HasMaxLength(100).IsUnicode(false).HasColumnName("copyright");

                entity.Property(e => e.Cover).HasColumnType("image").HasColumnName("cover");

                entity.Property(e => e.Nombre).HasMaxLength(50).IsUnicode(false).HasColumnName("nombre");

                entity.Property(e => e.Precio).HasMaxLength(10).HasColumnName("precio").IsFixedLength();

                entity.Property(e => e.Rating).HasColumnName("rating");

                entity.Property(e => e.FechaLanzamiento).HasColumnType("date").HasColumnName("fecha_lanzamiento");

                entity.Property(e => e.Resumen).IsUnicode(false).HasColumnName("resumen");
            });

            modelBuilder.Entity<Cancion>(entity =>
            {
                entity.ToTable("Cancion");

                entity.Property(e => e.ID).HasColumnName("id");

                entity.Property(e => e.AlbumID).HasColumnName("album_id");

                entity.Property(e => e.Duracion).HasColumnName("duracion");

                entity.Property(e => e.Nombre).HasMaxLength(50).IsUnicode(false).HasColumnName("nombre");

                entity.Property(e => e.Popularidad).HasColumnName("popularidad");

                entity.Property(e => e.Precio).HasColumnName("precio");

                entity.HasOne(d => d.Album).WithMany(p => p.Canciones).HasForeignKey(d => d.AlbumID).HasConstraintName("FK_Track_Album");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
