﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public partial class Album
    {
        public Album()
        {
            Canciones = new HashSet<Cancion>();
        }

        public int ID { get; set; }
        public string Nombre { get; set; } = null!;
        public string Resumen { get; set; } = null!;
        public double Rating { get; set; }
        public byte[] Cover { get; set; } = null!;
        public DateTime FechaLanzamiento { get; set; }
        public string Copyright { get; set; } = null!;
        public string Artista { get; set; } = null!;
        public string Precio { get; set; } = null!;

        public virtual ICollection<Cancion> Canciones { get; set; }

    }
}
