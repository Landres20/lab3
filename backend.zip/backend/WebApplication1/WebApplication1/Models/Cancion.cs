﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public class Cancion
    {

        public int ID { get; set; }
        public string Nombre { get; set; } = null!;
        public int Duracion { get; set; }
        public double Precio { get; set; }
        public int Popularidad { get; set; }
        public int? AlbumID { get; set; }
        public virtual Album? Album { get; set; }

    }
}
