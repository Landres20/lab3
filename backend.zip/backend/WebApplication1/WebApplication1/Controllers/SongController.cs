﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SongController : ControllerBase
    {

        private readonly cancionContext context;
        public SongController()
        {
            context = new cancionContext();
        }
        [HttpGet]
        public IActionResult Get()
        {
            var list = context.Canciones.ToList();
            return Ok(list);
        }

    }
}
