﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumController : ControllerBase
    {
        private readonly cancionContext context;

        public AlbumController()
        {
            context = new cancionContext();
        }

        [HttpGet]
        public IActionResult Get()
        {
            var list = context.Albums.ToList();
            return Ok(list);
        }

    }
}
