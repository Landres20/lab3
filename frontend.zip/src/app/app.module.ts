import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ReviewsComponent } from './componentes/reviews/reviews.component';
import { BusquedaComponent } from './componentes/busqueda/busqueda.component';
import { ListaCancionesComponent } from './componentes/lista-canciones/lista-canciones.component';
import { CancionesService } from './servicios/canciones/canciones.service';
import { AlbumService } from './servicios/album/album.service';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ListaCancionesComponent,
    ReviewsComponent,
    BusquedaComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [CancionesService, AlbumService],
  bootstrap: [AppComponent]
})
export class AppModule { }
