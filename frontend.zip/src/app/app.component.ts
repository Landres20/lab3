import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { finalize, Subject, takeUntil } from 'rxjs';
import { Album } from './interfaces/album.interface';
import { AlbumService } from './servicios/album/album.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy{
  title = 'lab3';
  stars: {checked: boolean}[]=[];

  album: Album | undefined;
  suscripcion: Subject<boolean> = new Subject();

  constructor(private albumService: AlbumService) {}

  ngOnInit(): void {
      this.albumService.getAlbums().pipe(takeUntil(this.suscripcion),finalize(()=>{ this.asignarRating(); })).subscribe(response => { this.album = response[0]; });
  }
  
  asignarRating():void {
    if(this.album.rating){
      this.album.rating = Math.round(this.album.rating);
      for(let i = 1; i <= this.album.rating; i++){
        this.stars.push({checked:true});
      }
      
      if(this.stars.length < 5){
        for(let i = this.stars.length; i < 5; i++){
          this.stars.push({checked:false});
        }
      }
    }
  }

  search(event: Event){  }

  ngOnDestroy(): void {
      this.suscripcion.next(true);
      this.suscripcion.complete();
  }

}
