export interface Album {
    id: number;
    name: string;
    summary: string;
    rating: number;
    cover: any;
    releaseDate: Date;
    copyright: string;
    artist: string;
    price: number;
}