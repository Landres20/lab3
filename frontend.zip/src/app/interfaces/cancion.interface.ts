export interface Canciones {
    id: number;
    name: string;
    duration: number;
    price: number;
    popularity: number;
    albumID: number;
}