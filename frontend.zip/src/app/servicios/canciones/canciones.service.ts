import { Injectable } from '@angular/core';
import { Canciones } from 'src/app/interfaces/cancion.interface';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable()
export class CancionesService {

  apiUrl = 'https://localhost:7254/api/Track'
  constructor(private httpClient:HttpClient) { }

  getCanciones() : Observable<Canciones[]>{
    return this.httpClient.get<Canciones[]>(this.apiUrl);
  }

}
