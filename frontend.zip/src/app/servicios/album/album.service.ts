import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Album } from 'src/app/interfaces/album.interface';

@Injectable()
export class AlbumService {

  private apiUrl = 'https://localhost:7254/api/Album';

  constructor(private httpClient: HttpClient) { }

  getAlbums(): Observable<Album[]> {
    return this.httpClient.get<Album[]>(this.apiUrl);
  }
  
}
