import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Canciones } from 'src/app/interfaces/cancion.interface';

@Component({
  selector: 'app-busqueda',
  templateUrl: './busqueda.component.html',
  styleUrls: ['./busqueda.component.css']
})
export class BusquedaComponent implements OnInit {

  @Input() canciones: Canciones[] = [];
  @Output() buscarEvento: EventEmitter<Canciones[]> = new EventEmitter();
  searchForm: FormGroup;

  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
    this.searchForm=this.fb.group({ search: [''] });
  }

  buscar(){
    this.canciones = this.canciones.filter(cancion => cancion.name.toLowerCase().includes(this.searchForm.value.search.toLowerCase()));
    this.buscarEvento.emit(this.canciones);
  }

}
