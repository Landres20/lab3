import { Component, OnInit, Input } from '@angular/core';
import { Album } from 'src/app/interfaces/album.interface';

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent {

  @Input() resumen: string = '';

}
