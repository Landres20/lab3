import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { Observable } from 'rxjs';
import { Canciones } from 'src/app/interfaces/cancion.interface';
import { CancionesService } from 'src/app/servicios/canciones/canciones.service';
import { Album } from 'src/app/interfaces/album.interface';
import { AlbumService } from 'src/app/servicios/album/album.service';

@Component({
  selector: 'app-lista-canciones',
  templateUrl: './lista-canciones.component.html',
  styleUrls: ['./lista-canciones.component.css']
})
export class ListaCancionesComponent implements OnInit, OnDestroy {

  canciones: Canciones[] = [];
  album: Album[] = [];
  suscripcion: Subject<boolean> = new Subject();
  graficaPopularidad: {checked: boolean}[] = [];
  flipCaret: boolean = false;
  sortStatus: boolean = false;

  constructor(private cancionesService:CancionesService, private albumService:AlbumService) { }

  ngOnInit(): void {
    this.getCanciones();
    this.getAlbum();
  }

  ngOnDestroy(): void {
      this.suscripcion.next(true);
      this.suscripcion.complete();
  }

  getCanciones():void{
    this.cancionesService.getCanciones().pipe(takeUntil(this.suscripcion)).subscribe(response => { this.canciones = response; });
  }

  getAlbum():void{
    this.albumService.getAlbums().pipe(takeUntil(this.suscripcion)).subscribe(response => { this.album = response; });
  }

  getArtistaDeCancion(id:number):string{
    if(this.canciones&&this.album){
      const albumID = this.canciones.find(cancion => cancion.id === id).albumID;
      const artist = this.album.find(album => album.id === albumID).artist;
      return artist;
    }else{
      return 'No se encontro artista';
    }
  }

  getGraficaPopularidad(id:number):{checked:boolean}[]{
    let graficaPopularidad:{checked:boolean}[]=[];
    if(this.canciones){
      const popularidad = this.canciones.find(cancion => cancion.id === id).popularity;
      this.graficaPopularidad.fill({checked:false},0,100);
      for(let i=0; i<popularidad; i++){
        graficaPopularidad[i]={checked:true};
      }
    }
    return graficaPopularidad;
  }

  sortAscendente(){
    this.canciones.sort((a,b) => {
      if(a.name > b.name){
        return 1;
      }
      if(a.name < b.name){
        return -1;
      }
      return 0;
    });
    this.sortStatus = true;
    this.flipCaret = !this.flipCaret;
  }

  sortDescendente(){
    this.canciones.sort((a,b) => {
      if(a.name < b.name){
        return 1;
      }
      if(a.name > b.name){
        return -1;
      }
      return 0;
    });
    this.sortStatus = false;
    this.flipCaret = !this.flipCaret;
  }

  sort(){
    if(this.sortStatus){
      this.sortDescendente();
    }else{
      this.sortAscendente();
    }
  }

}
